const XLSX = require('xlsx');

// Leer el archivo Excel
const workbook = XLSX.readFile('PRODUCTOS.xlsx');
const sheetName = workbook.SheetNames[0]; // Toma la primera hoja
const worksheet = workbook.Sheets[sheetName];
const jsonData = XLSX.utils.sheet_to_json(worksheet);

// Mapear encabezados alternativos a los nombres esperados
const headerMapping = {
  'P.V.': 'PV',
  'Precio al 50%': '0.50', // Mapear "Precio al 50%" a "0.50"
  '0.5': '0.50', // Mapear "0.5" a "0.50"
  '0.50': '0.50', // Mapear "0.50" a "0.50"
  'Precio al 25%': '0.25',
  '0.25': '0.25',
  'Precio al 35%': '0.35',
  '0.35': '0.35',
  'Precio al 42%': '0.42',
  '0.42': '0.42',
  'Base de Ganancia': 'BASE_DE_GANANCIA',
  'Precio de Venta Sugerido': 'PRECIO_DE_VENTA_SUGERIDO',
  'Nombre del Producto': 'NOMBRE_DEL_PRODUCTO'
};

// Ajustar los datos para incluir 'quantity' y manejar valores numéricos
const adjustedData = jsonData.map(row => {
  const mappedRow = {};
  for (let key in row) {
    const normalizedKey = headerMapping[key.trim()] || key.trim();
    mappedRow[normalizedKey] = typeof row[key] === 'string' ? row[key].trim() : row[key];
  }
  return {
    SKU: mappedRow.SKU || '',
    NOMBRE_DEL_PRODUCTO: mappedRow.NOMBRE_DEL_PRODUCTO || '',
    SABOR: mappedRow.SABOR || '',
    PV: parseFloat(mappedRow.PV) || 0,
    BASE_DE_GANANCIA: parseFloat(mappedRow.BASE_DE_GANANCIA) || 0,
    PRECIO_DE_VENTA_SUGERIDO: parseFloat(mappedRow.PRECIO_DE_VENTA_SUGERIDO) || 0,
    '0.25': parseFloat(mappedRow['0.25']) || 0,
    '0.35': parseFloat(mappedRow['0.35']) || 0,
    '0.42': parseFloat(mappedRow['0.42']) || 0,
    '0.50': parseFloat(mappedRow['0.50']) || 0, // Usar '0.50' como clave
    CATEGORIA: mappedRow.CATEGORIA || 'BATIDOS',
    quantity: 0 // Inicializar quantity en 0
  };
});

// Guardar como products.json
const fs = require('fs');
fs.writeFileSync('products.json', JSON.stringify(adjustedData, null, 2));
console.log('Archivo products.json generado con éxito.');